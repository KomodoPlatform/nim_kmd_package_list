##Main State
* Add GUI:
  * Player list
  * Chat box
  * Escape menu

##Lobby
* Add GUI: 
  * options menu
  * key configuration

## Animations
* Need one-shot explosion animations
  * Thrusters (maybe a particle system instead)

## Networking
* zone server should verify users through the dir server or handle its own users
* directory server should handle asset patching

## Genpacket
* add support for branching types with case
